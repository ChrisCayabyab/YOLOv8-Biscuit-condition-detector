# Circle Biscuit > 2024-07-15 7:58am
https://universe.roboflow.com/yolo-training-xpbmj/circle-biscuit

Provided by a Roboflow user
License: CC BY 4.0

